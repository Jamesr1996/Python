import sys
import Brick
import math
import pygame
from pygame.locals import *

class Breakout:

    # Constructor of the breakout class.
    # This constructor calls initialize and main_loop method.
    def __init__(self):
        self.initialize()
        self.main_loop()

     
    # Initialization method. Generates the game window and sets parameters
    # of game operation.
    def initialize(self):
        pygame.init()
        pygame.key.set_repeat(1, 1)

        # Set window size
        self.screen = pygame.display.set_mode((1024, 768))

        # Set caption of window
        pygame.display.set_caption("Breakout")
        
        self.framerate = 30               
                    
        self.clock = pygame.time.Clock()

        # Sets the game state to 1
        self.gameState = 1

        self.font = pygame.font.Font(None, 40)
        self.font2 = pygame.font.Font(None, 24)        

        # Calls the initiliazeGameVariables() method.
        self.initializeGameVariables()

        
    # InitializeGameVariables loads the items used in the game 
    def initializeGameVariables(self):

        # Load Background
        self.background = pygame.image.load('background.png')
        # Load Bat 
        self.batImage = pygame.image.load('bat6.png')
        # Load the Ball
        self.ballImage = pygame.image.load('Ball.png')
        # Load the Purple brick
        self.purpleBrickImage = pygame.image.load('Brick.png')
        # Load the Red brick
        self.redBrickImage = pygame.image.load('Brick2.png')
        # Load the Green Brick        
        self.greenBrickImage = pygame.image.load('Brick3.png')
        # Load the Orange Brick
        self.orangeBrickImage = pygame.image.load('Brick4.png')
        # Load the Blue Brick
        self.blueBrickImage = pygame.image.load('Brick5.png')
        # Load the Bat Hit Sound
        self.batHit = pygame.mixer.Sound("blip.wav")
        # Load the Brick Hit Sound
        self.brickHit = pygame.mixer.Sound("blurp.wav")
        # Load the Wall Bounce Sound
        self.wallHit = pygame.mixer.Sound("womp.wav")
                

        # set the starting position for the bat object.
        self.batPosX = 496
        self.batPosY = 700

        # set the starting position for the ball object.
        self.ballPosX = 496
        self.ballPosY = 600

        # set the ball X and Y directions.
        self.ballXDirection = 3
        self.ballYDirection = 6

        # Creates the playerscore variable.
        self.playerScore = 0

        self.ticks = 0

        # Creates lists to hold the locations for each colour brick 
        self.pBricks = []
        self.redBricks = []
        self.blueBricks = []
        self.greenBricks = []
        self.orangeBricks = []
        
        # Create the number of bricks to be used and set their position.         
        yPos = 200
        amountOfRows = 2
        amountOfColumns = 12
        for row in range(amountOfRows):
            xPos = 200
            for column in range(amountOfColumns):
                # Set the position of Purple Bricks.
                Pbrick = Brick.Brick()
                Pbrick.setPosX(xPos)
                Pbrick.setPosY(yPos)
                self.pBricks.append(Pbrick)
                
                # Set the position of Red Bricks.
                Rbrick = Brick.Brick()
                Rbrick.setPosX(xPos)
                Rbrick.setPosY(yPos+40)
                self.redBricks.append(Rbrick)

                # Set the position of Green Bricks.
                Gbrick = Brick.Brick()
                Gbrick.setPosX(xPos)
                Gbrick.setPosY(yPos+80)
                self.greenBricks.append(Gbrick)

                # Set the position of Blue Bricks.
                Bbrick = Brick.Brick()
                Bbrick.setPosX(xPos)
                Bbrick.setPosY(yPos+120)
                self.blueBricks.append(Bbrick)

                # Set the position of Orange Bricks.
                Obrick = Brick.Brick()
                Obrick.setPosY(yPos+160)
                Obrick.setPosX(xPos)
                self.orangeBricks.append(Obrick)

                # Create the spaces between bricks.
                xPos += 50
            yPos += 20
            
# End of initializeGameVariables method

    # main loop method keeps the game running. This constantly
    # calls the update and draw methods to cycle the game. 
    def main_loop(self):
        self.clock = pygame.time.Clock()
        while True:
            gametime = self.clock.get_time()
            self.update(gametime)
            self.draw(gametime)
            self.clock.tick(self.framerate)
                 
    # Executes during the 1st game state, detects input and responds accordingly.
    def updateStarted(self, gametime):

        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # On 'S' pressed, set gamestate 2
                if event.key == pygame.K_s:
                    self.gameState = 2
                # On 'H' pressed, Set gamestate 4
                elif event.key == pygame.K_h:
                    self.gameState = 4
                    break
                                
# Start of updatePlayingMethod
    def updatePlaying(self, gametime):
        events = pygame.event.get()

    # Decide the actions to be taken when input is given.
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:

                # Moves the bat left and right 
                if event.key == pygame.K_LEFT:
                    self.batPosX = self.batPosX - 10
                if event.key == pygame.K_RIGHT:
                    self.batPosX = self.batPosX + 10
                if event.key == pygame.K_q:
                    self.ballXDirection = self.ballXDirection * 2
                    self.ballYDirection = self.ballYDirection * 2
                if event.key == pygame.K_w:
                    self.ballXDirection = self.ballXDirection / 2
                    self.ballYDirection = self.ballYDirection /2

        self.ticks = self.ticks + gametime
        # Moves the ball in the direction of X and Y.        
        self.ballPosX = self.ballPosX + self.ballXDirection
        self.ballPosY = self.ballPosY + self.ballYDirection

        # Prevents the bat from going off screen at both directions.
        if self.batPosX < 0:
            self.batPosX = 0
        if self.batPosX > 944:
            self.batPosX = 944
        
        # Creates the ball rectangle object 
        rectBall = pygame.Rect(self.ballPosX, self.ballPosY, self.ballImage.get_width(),
                               self.ballImage.get_height())

        # Creates the bat rectangle object
        rectBatLeft = pygame.Rect(self.batPosX, self.batPosY, math.ceil(self.batImage.get_width()*(1/5)),
                              self.batImage.get_height())

        rectBatRight = pygame.Rect(self.batPosX + math.ceil(self.batImage.get_width()*(4/5)), self.batPosY, math.ceil(self.batImage.get_width()*(1/5)),
                              self.batImage.get_height())

        rectBatMid = pygame.Rect(self.batPosX + math.ceil(self.batImage.get_width()*(1/5)), self.batPosY, math.ceil(self.batImage.get_width()*(3/5)),
                              self.batImage.get_height())


        # Creates and detects collisions between the ball and the bricks.
        #~ For loop start
        for i in range(24):
            
            if self.pBricks[i] != None:
                # Create a rectangle object for purple bricks
                rectPBrick = pygame.Rect(self.pBricks[i].getPosX(), self.pBricks[i].getPosY(),
                                         self.purpleBrickImage.get_width(), self.purpleBrickImage.get_height())        
                if rectBall.colliderect(rectPBrick):
                    # Remove the brick
                    self.pBricks[i] = None
                    # Changes the direction of the ball in the Y direction upon contacting Purple brick.
                    self.ballYDirection = self.ballYDirection * -1
                    # Play Brick hit sound.
                    self.brickHit.play()
                    # Increment score by 50.
                    self.playerScore = self.playerScore + 50
                    break                   
                                
            if self.redBricks[i] != None:
                rectRBrick = pygame.Rect(self.redBricks[i].getPosX(), self.redBricks[i].getPosY(),
                                         self.redBrickImage.get_width(), self.redBrickImage.get_height())
                if rectBall.colliderect(rectRBrick):
                    self.redBricks[i] = None
                    # Changes the direction of the ball in the Y direction upon contacting Red brick.
                    self.ballYDirection = self.ballYDirection * -1
                    self.brickHit.play()
                    self.playerScore = self.playerScore + 50
                    break
                

            if self.blueBricks[i] != None:
                # Create a rectangle object for blue bricks
                rectBBrick = pygame.Rect(self.blueBricks[i].getPosX(), self.blueBricks[i].getPosY(),
                                         self.blueBrickImage.get_width(), self.blueBrickImage.get_height())
                if rectBall.colliderect(rectBBrick):
                    self.blueBricks[i] = None                        
                    # Changes the direction of the ball in the Y direction upon contacting Blue brick.
                    self.ballYDirection = self.ballYDirection * -1
                    self.brickHit.play()
                    self.playerScore = self.playerScore + 50
                    break

            if self.greenBricks[i] != None:
                # Create a rectangle object for green bricks
                rectGBrick = pygame.Rect(self.greenBricks[i].getPosX(), self.greenBricks[i].getPosY(),
                                         self.greenBrickImage.get_width(), self.greenBrickImage.get_height())
                if rectBall.colliderect(rectGBrick):
                    self.greenBricks[i] = None
                    # Changes the direction of the ball in the Y direction upon contacting Green brick.
                    self.ballYDirection = self.ballYDirection * -1
                    self.brickHit.play()
                    self.playerScore = self.playerScore + 50
                    break

            if self.orangeBricks[i] != None:
                # Create a rectangle object for orange bricks
                rectOBrick = pygame.Rect(self.orangeBricks[i].getPosX(), self.orangeBricks[i].getPosY(),
                                         self.orangeBrickImage.get_width(), self.orangeBrickImage.get_height())
                if rectBall.colliderect(rectOBrick):
                    self.orangeBricks[i] = None
                    # Changes the direction of the ball in the Y direction upon contacting Orange brick.
                    self.ballYDirection = self.ballYDirection * -1
                    self.brickHit.play()
                    self.playerScore = self.playerScore + 50
                    break                 
        #~ For loop end
        
        # Detects the collision between the ball and the bat.
        if rectBall.colliderect(rectBatLeft):
            if self.ballYDirection > 0:
                self.ballYDirection = self.ballYDirection * -1
            self.ballXDirection = -5
            self.batHit.play()

        # Detects collision between ball and the Middle of bat
        # and sets the direction of the ball dependent on the current direction
        if rectBall.colliderect(rectBatMid):
            if self.ballYDirection > 0:
                self.ballYDirection = self.ballYDirection * -1
            if self.ballXDirection > 0:
                self.ballXDirection = 2
            if self.ballXDirection < 0:
                self.ballXDirection = -2
            # Plays the ball hit sound upon contact.
            self.batHit.play()

        # Detects collision between the ball and the Right side of bat
        # and sets the direction of the ball
        if rectBall.colliderect(rectBatRight):
            if self.ballYDirection > 0:
                # Reverse the Y direction
                self.ballYDirection = self.ballYDirection * -1
            self.ballXDirection = 5
            # Play the bat hit sound upon contact.
            self.batHit.play()
                  
        # Bounces the ball from disappearing off the right hand screen
        if self.ballPosX > 1004:
            self.ballXDirection = self.ballXDirection * -1
            self.wallHit.play()

        # Bounces the ball from disappearing off the left hand screen
        if self.ballPosX < 1:
            self.ballXDirection = self.ballXDirection * -1
            self.wallHit.play()

        # Bounces the ball from disappearing off the top of the screen
        if self.ballPosY < 1:
            self.ballYDirection = self.ballYDirection * -1
            self.wallHit.play()

        # Ends the game if the ball travels off the bottom of the screen.
        if self.ballPosY > 768:
            self.gameState = 3

        # Compile the bricks into a single list.
        self.aBricks = self.redBricks + self.pBricks + self.greenBricks + self.blueBricks + self.orangeBricks
        
        # Check if all bricks have been set to "None", if so, end the game.
        if all(i == None for i in self.aBricks):
            self.gameState = 3        
# End of updatePlaying Method            

    # Detects input during the 3rd game state
    def updateEnded(self, gametime):
        events = pygame.event.get()
        # detects input for game events.
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # 'q' quits the game
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
                # 'r' restarts the game
                elif event.key == pygame.K_r:
                    self.initializeGameVariables()
                    self.gameState = 1
                # 'h' displays the help screen
                elif event.key == pygame.K_h:
                    self.gameState = 4

    # Detects input during the 4th game state
    def updateHelpScreen(self, gametime):
        events = pygame.event.get()
        # detects input for game events.
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # 'q' quits the game
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
                # 's' starts the game
                elif event.key == pygame.K_s:
                    self.initializeGameVariables()
                    self.gameState = 2
                    
    # Update method changes update state dependent on gamestate.
    def update(self, gametime):        
        if self.gameState == 1:
            self.updateStarted(gametime)
        elif self.gameState == 2:
            self.updatePlaying(gametime)
        elif self.gameState == 3:
            self.updateEnded(gametime)
        elif self.gameState == 4:
            self.updateHelpScreen(gametime)
            
    # Creates the title screen
    # xPos is a method unique variable that is overwritten after each use.
    def drawStarted(self, gametime):
        # Draw background
        self.screen.blit(self.background, (0, 0))
        # receives the width and height from the text ("B R E A K O U T!")
        width, height = self.font.size("B R E A K O U T!")
        # Sets the font size/colour and style.
        text = self.font.render("B R E A K O U T!", True, (255, 0, 0))
        # Sets the position of the text to the centre of the screen
        xPos = (1024 - width) / 2
        # Draws the text on the screen at the position specified.
        self.screen.blit(text, (xPos, 200))
        # receives the width and height from the text
        width, height = self.font.size("P R E S S   'S'   T O   S T A R T")
        # Sets the font size/colour and style.
        text = self.font.render("P R E S S   'S'   T O   S T A R T", True, (255, 0, 0))
        # Sets the position of the text to the centre of the screen
        xPos = (1024 - width) / 2
        # Draws the text on the screen at the position specified.
        self.screen.blit(text, (xPos, 400))
        # receives the width and height from the text
        width, height = self.font.size("P R E S S   'H'  F O R   H E L P")
        # Sets the font size/colour and style.
        text = self.font.render("P R E S S   'H'  F O R   H E L P", True, (255, 0, 0))
        # Sets the position of the text to the centre of the screen
        xPos = (1024 - width) / 2
        # Draws the text on the screen at the position specified.
        self.screen.blit(text, (xPos, 500))
        pygame.display.flip()

        
    def drawPlaying(self, gametime):
        # draw background
        self.screen.blit(self.background, (0,0))
        # draw bat
        self.screen.blit(self.batImage, (self.batPosX, self.batPosY))
        # Create a loop specifying how many bricks to display
        for i in range(24):
            # draw purple bricks
            if self.pBricks[i] != None:
                self.screen.blit(self.purpleBrickImage, self.pBricks[i].getPosition())
            # draw red bricks
            if self.redBricks[i] != None:
                self.screen.blit(self.redBrickImage, self.redBricks[i].getPosition())
            # draw blue bricks
            if self.blueBricks[i] != None:
                self.screen.blit(self.blueBrickImage, self.blueBricks[i].getPosition())
            # draw green bricks
            if self.greenBricks[i] != None:
                self.screen.blit(self.greenBrickImage, self.greenBricks[i].getPosition())
            # draw orange bricks
            if self.orangeBricks[i] != None:
                self.screen.blit(self.orangeBrickImage, self.orangeBricks[i].getPosition())
        # draw ball
        self.screen.blit(self.ballImage, (self.ballPosX, self.ballPosY))
        # draw the current score at the top right of the screen
        width, height = self.font.size("SCORE: %d" % self.playerScore)
        text = self.font.render("SCORE: %d" % self.playerScore, True, (255, 0, 0))
        xPos = (700)
        self.screen.blit(text, (xPos, 50))
        
        pygame.display.flip()
       
                    
    # Draw method, draws the current state of the game on the screen                        
    def draw(self, gametime):
        # Switches states depending on the current gamestate
        if self.gameState == 1:
            self.drawStarted(gametime)
        elif self.gameState == 2:
            self.drawPlaying(gametime)
        elif self.gameState == 3:
            self.drawEnded(gametime)
        elif self.gameState == 4:
            self.drawHelpScreen(gametime)

                     
    def drawEnded(self, gametime):
        # Draws the background
        self.screen.blit(self.background, (0, 0))
        # Set the width and height of the text
        width, height = self.font.size("G A M E   O V E R !")
        # Set the font, colour and style of text.
        text = self.font.render("G A M E   O V E R !", True, (255, 0, 0))
        # Set centre of screen position
        xPos = (1024 - width) / 2
        # Draw text to screen at location specified.
        self.screen.blit(text,(xPos, 200))
        # Set the width and height of the text
        width, height = self.font.size("Y O U R   S C O R E: %d" %self.playerScore)
        # Set the font, colour and style of text.
        text = self.font.render("Y O U R   S C O R E: %d" %self.playerScore, True, (255,0,0))
        # Set centre of screen position
        xPos = (1024 - width) / 2
        # Draw text to screen at location specified.
        self.screen.blit(text,(xPos, 300))
        # Set the width and height of the text
        width, height = self.font.size("P R E S S   'R'   T O   R E S T A R T   O R   'Q'   T O   Q U I T")
        # Set the font, colour and style of text.
        text = self.font.render("P R E S S   'R'   T O   R E S T A R T   O R   'Q'   T O   Q U I T", True, (255, 0, 0))
        # Set centre of screen position
        xPos = (1024 - width) / 2
        # Draw text to screen at location specified.
        self.screen.blit(text, (xPos, 650))
        # Set the width and height of the text
        width, height = self.font.size("P R E S S   'H'   F O R   H E L P S C R E E N")
        # Set the font, colour and style of text.
        text = self.font.render("P R E S S   'H'   F O R   H E L P S C R E E N", True, (255, 0, 0))
        # Set centre of screen position
        xPos = (1024 - width) / 2
        # Draw text to screen at location specified.
        self.screen.blit(text, (xPos, 700))
        
        pygame.display.flip() 

    def drawHelpScreen(self, gametime):
        self.screen.blit(self.background, (0, 0))
        # Set the width and height of the text
        width, height = self.font.size("H O W   T O   P L A Y !")
        # Set the font, colour and style of text.
        text = self.font.render("H O W   T O   P L A Y !", True, (255, 0, 0))
        # Set centre of screen position
        xPos = (1024 - width) / 2
        # Draw text to screen at location specified.
        self.screen.blit(text, (xPos, 200))
        # Create text used for help menu in the next 4 lines.
        text = self.font2.render("The objective of the game is to destroy all the bricks by bouncing the ball off the paddle.",
                                 True, (255, 0, 0))
        text2 = self.font2.render("Once all the bricks have been destroyed the game ends.", True, (255, 0, 0))
        text3 = self.font2.render("If the ball goes off the bottom of the screen, the player loses and the game is over.", True, (255,0,0))
        text4 = self.font2.render("You can speed up and slow the ball using the 'Q' and 'W' keys respectively.", True, (255, 0, 0))    
        # Draw help screen text.
        self.screen.blit(text, (150, 300))
        self.screen.blit(text2, (150, 330))
        self.screen.blit(text3, (150, 360))
        self.screen.blit(text4, (150, 390))
        # Set the width and height of the text
        width, height = self.font.size("P R E S S   'S'   T O   S T A R T")
        # Set the font, colour and style of text
        text = self.font.render("P R E S S   'S'   T O   S T A R T   O R   'Q'   T O   Q U I T", True, (255, 0, 0))
        # Set a fixed X position to display the text
        xPos = (150)
        # Draw the text to the screen at the location specified.
        self.screen.blit(text, (xPos, 650))
        
        pygame.display.flip()
        
# Run the program.
if __name__ == "__main__":
    game = Breakout()
