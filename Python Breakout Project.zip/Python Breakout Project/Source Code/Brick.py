# Creates the template for setting and retrieving brick positions
# Used in the Breakout class

class Brick:

    # Sets the default values for brick Position x and Position y
    def __init__(self):
        self.__brickPosX = 0
        self.__brickPosY = 0

    # Changes the Brick Position x
    def setPosX(self, x):
        self.__brickPosX = x

    # Changes the Brick Position y
    def setPosY(self, y):
        self.__brickPosY = y

    # Returns the Brick Position x
    def getPosX(self):
        return self.__brickPosX

    # Returns the Brick Position y
    def getPosY(self):
        return self.__brickPosY

    # Returns Both the Brick X and Y Positions.
    def getPosition(self):
        return (self.__brickPosX, self.__brickPosY)
