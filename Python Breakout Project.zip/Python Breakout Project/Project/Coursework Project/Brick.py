class Brick:

    def __init__(self):
        self.__brickPosX = 0
        self.__brickPosY = 0

    def setPosX(self, x):
        self.__brickPosX = x

    def setPosY(self, y):
        self.__brickPosY = y

    def getPosX(self):
        return self.__brickPosX

    def getPosY(self):
        return self.__brickPosY

    def getPosition(self):
        return (self.__brickPosX, self.__brickPosY)
