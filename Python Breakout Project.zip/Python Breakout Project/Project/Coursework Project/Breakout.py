import sys
import Brick
import pygame
from pygame.locals import *

class Breakout:

    # Constructor of the basic game class.
    # This constructor calls initialize and main_loop method.
    def __init__(self):
        self.initialize()
        self.main_loop()


        

    # Initialization method. Generates the game window and sets parameters
    # of game operation.
    def initialize(self):
        pygame.init()
        pygame.key.set_repeat(1, 1)

        self.width = 1024
        self.height = 768
        self.screen = pygame.display.set_mode((self.width, self.height))

        self.caption = "Breakout"
        pygame.display.set_caption(self.caption)
        
        self.framerate = 30               
                    
        self.clock = pygame.time.Clock()

        # Sets the game state to 1
        self.gameState = 1

        self.font = pygame.font.Font(None, 40)

        # Calls the initiliazeGameVariables() method.
        self.initializeGameVariables()

        


    # InitializeGameVariables loads the items used in the game 
    def initializeGameVariables(self):

        self.background = pygame.image.load('background.png')
        self.batImage = pygame.image.load('bat6.png')
        self.purpleBrickImage = pygame.image.load('Brick.png')
        self.redBrickImage = pygame.image.load('Brick2.png')
        self.ballImage = pygame.image.load('Ball.png')

        # set the starting position for the bat object.
        self.batPosX = 496
        self.batPosY = 700

        self.ballPosX = 496
        self.ballPosY = 600

        self.ballXDirection = 3
        self.ballYDirection = 6
        
        
        
        self.playerScore = 0

        self.ticks = 0

        self.pBricks = []
        self.redBricks = []

        # Create the number of purple bricks to be used and set their position. 
        
        
        yPos = 100
        for i in range(12):
            xPos = 200
            for x in range(10):
                
                Pbrick = Brick.Brick()
                Pbrick.setPosX(xPos)
                Pbrick.setPosY(yPos)
                self.pBricks.append(Pbrick)

        # Create the number of red bricks to be used and set their position.
                Rbrick = Brick.Brick()
                Rbrick.setPosX(xPos)
                Rbrick.setPosY(yPos + 30)
                self.redBricks.append(Rbrick)
                xPos += 50
            yPos += 30

        
        
            
            
            

    # main loop method keeps the game running. This method continuously
    # calls the update and draw methods to keep the game alive.
    def main_loop(self):
        self.clock = pygame.time.Clock()
        while True:
            gametime = self.clock.get_time()
            self.update(gametime)
            self.draw(gametime)
            self.clock.tick(self.framerate)

            
                  

    def updateStarted(self, gametime):

        events = pygame.event.get()

        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    self.gameState = 2
                    break


                

    def updatePlaying(self, gametime):
        events = pygame.event.get()

    # Decide the actions to be taken when input is given.
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:

                # Moves the bat left and right 
                if event.key == pygame.K_LEFT:
                    self.batPosX = self.batPosX - 10
                if event.key == pygame.K_RIGHT:
                    self.batPosX = self.batPosX + 10

        isBrickRemaining = False

        # Checks whether all the bricks have been removed. 
        for i in range (12):
            if (self.pBricks[i] != None) or self.redBricks[i] != None:
                isBrickRemaining = True
                break

        self.ticks = self.ticks + gametime

        # Moves the ball in the direction of X and Y.        
        self.ballPosX = self.ballPosX + self.ballXDirection
        self.ballPosY = self.ballPosY + self.ballYDirection

        # Prevents the bat from going off screen at both directions.
        if self.batPosX < 100:
            self.batPosX = 100

        if self.batPosX > 900:
            self.batPosX = 900

    # ========================================================================================= Modifications Needed
        
        # Creates the ball rectangle object 
        rectBall = pygame.Rect(self.ballPosX, self.ballPosY, self.ballImage.get_width(),
                               self.ballImage.get_height())

        # Creates the bat rectangle object
        rectBatLeft = pygame.Rect(self.batPosX, self.batPosY, 26,
                              self.batImage.get_height())

        rectBatRight = pygame.Rect(self.batPosX + 52, self.batPosY, 26,
                              self.batImage.get_height())

        rectBatMid = pygame.Rect(self.batPosX + 26, self.batPosY, 26,
                              self.batImage.get_height())


        # Creates and detects collisions between the ball and the bricks.
        for i in range(12):
            
            if self.pBricks[i] != None:
                
                rectPBrick = pygame.Rect(self.pBricks[i].getPosX(), self.pBricks[i].getPosY(),
                                         self.purpleBrickImage.get_width(), self.purpleBrickImage.get_height())
    
                if rectBall.colliderect(rectPBrick):
                    self.pBricks[i] = None
                    
                # Changes the direction of the ball in the Y direction upon contacting a brick.
                    self.ballYDirection = self.ballYDirection * -1
                    
                    self.playerScore = self.playerScore + 100
                    break
                   
                
                
            if self.redBricks[i] != None:
                rectRBrick = pygame.Rect(self.redBricks[i].getPosX(), self.redBricks[i].getPosY(),
                                         self.redBrickImage.get_width(), self.redBrickImage.get_height())

                if rectBall.colliderect(rectRBrick):
                    self.redBricks[i] = None
                    
                # Changes the direction of the ball in the Y direction upon contacting a brick.
                    self.ballYDirection = self.ballYDirection * -1

                    self.playerScore = self.playerScore + 50
                    break
        
        # Detects the collision between the ball and the bat.
        
        if rectBall.colliderect(rectBatLeft):
            self.ballYDirection = self.ballYDirection * -1
            self.ballXDirection = self.ballXDirection * -2

        if rectBall.colliderect(rectBatMid):
            self.ballYDirection = self.ballYDirection * -1

        if rectBall.colliderect(rectBatRight):
            self.ballYDirection = self.ballYDirection * -1
            self.ballXDirection = self.ballXDirection * -2
      # =========================================================================================================      

        if self.ballPosX > 1004:
            self.ballXDirection = self.ballXDirection * -1

        if self.ballPosX < 1:
            self.ballXDirection = self.ballXDirection * -1

        if self.ballPosY < 1:
            self.ballYDirection = self.ballYDirection * -1

        
            

    def updateEnded(self, gametime):

        events = pygame.event.get()

        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_r:
                    self.initializeGameVariables()
                    self.gameState = 1


    # Update method initializes different update methods based on
    # game state.
    def update(self, gametime):        
        if self.gameState == 1:
            self.updateStarted(gametime)
        elif self.gameState == 2:
            self.updatePlaying(gametime)
        elif self.gameState == 3:
            self.updateEnded(gametime)
            

    def drawStarted(self, gametime):
        self.screen.blit(self.background, (0, 0))

        width, height = self.font.size("B R E A K O U T!")
        text = self.font.render("B R E A K O U T!", True, (255, 0, 0))

        xPos = (1024 - width) / 2
        self.screen.blit(text, (xPos, 200))

        width, height = self.font.size("P R E S S   'S'   T O   S T A R T")
        text = self.font.render("P R E S S   'S'   T O   S T A R T", True, (255, 0, 0))
        xPos = (1024 - width) / 2
        self.screen.blit(text, (xPos, 400))

        pygame.display.flip()

        

    def drawPlaying(self, gametime):
        self.screen.blit(self.background, (0,0))

        self.screen.blit(self.batImage, (self.batPosX, self.batPosY))

        for i in range(24):
            if self.pBricks[i] != None:
                self.screen.blit(self.purpleBrickImage, self.pBricks[i].getPosition())

        for i in range(24):
            if self.redBricks[i] != None:
                self.screen.blit(self.redBrickImage, self.redBricks[i].getPosition())

        self.screen.blit(self.ballImage, (self.ballPosX, self.ballPosY))
    
        pygame.display.flip()

        
                    
    # Draw method, draws the current state of the game on the screen                        
    def draw(self, gametime):
        if self.gameState == 1:
            self.drawStarted(gametime)
        elif self.gameState == 2:
            self.drawPlaying(gametime)
        elif self.gameState == 3:
            self.drawEnded(gametime)

                     

    def drawEnded(self, gametime):
        
        self.screen.blit(self.background, (0, 0))
        self.screen.blit(self.batImage, (self.batPosX, self.batPosY))
        
        pygame.display.flip() 
           

if __name__ == "__main__":
    game = Breakout()
